//import React from "react";
import ReactDOM from "react-dom/client";

function App() {
  return (
    <div style={{ padding: 40, textAlign: "center" }}>
      <h1>✅ Luz del Camino App funcionando</h1>
      <p>Compilación exitosa con Vite + React</p>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")!).render(<App />);